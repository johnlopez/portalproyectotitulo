<?php
class Crud extends CI_Controller
{
    public function __construct()
    {
        //Cargamos El Constructor
        parent::__construct();
        //Cargamos El modelo usuarios
        $this->load->model('usuarios_model');
        //Cargamos la libreria Form_validation para nuestro formulario
        $this->load->library('form_validation');
        //cargamos el helper url para utlizar el base_url
        $this->load->helper('url');
    }
     
    public function index()
    {
        //Si Existe Post y es igual a uno
        if($this->input->post('post') && $this->input->post('post')==1)
        {
            $this->form_validation->set_rules('username', 'Username', 'required|trim|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'required|trim|xss_clean');
          
             
            $this->form_validation->set_message('required','El Campo <b>%s</b> Es Obligatorio');
            $this->form_validation->set_message('numeric','El Campo <b>%s</b> Solo Acepta Números');
            if ($this->form_validation->run() == TRUE)
            {
                $username = $this->input->post('username');
                $password = $this->input->post('password');
                $hash = $this->encrypt->sha1($password);
                
                $this->usuarios_model->agregar_usuario($username,$hash);               
            }
        }
        //obtenemos todos los usuarios
        $usuarios = $this->usuarios_model->get_usuarios();
        //creamos una variable usuarios para pasarle a la vista
        $data['usuarios'] = $usuarios;
        //cargamos nuestra vista
        $this->load->view('index_view',$data);
    }
     
    public function editar($id=0)
    {
        //verificamos si existe el id
        $respuesta = $this->usuarios_model->get_usuario($id);
        //si nos retorna FALSE le mostramos la pag 404
        if($respuesta==false)
        show_404();
        else
        {
            //Si existe el post para editar
            if($this->input->post('post') && $this->input->post('post')==1)
            {
                $this->form_validation->set_rules('username', 'Username', 'required|trim|xss_clean');
                $this->form_validation->set_rules('password', 'Password', 'required|trim|xss_clean');
                
                 
                $this->form_validation->set_message('required','El Campo <b>%s</b> Es Obligatorio');
                $this->form_validation->set_message('numeric','El Campo <b>%s</b> Solo Acepta Números');
                if ($this->form_validation->run() == TRUE)
                {
                    $username = $this->input->post('username');
                    $password = $this->input->post('password');
                    
                    $this->usuarios_model->actualizar_usuario($id,$username,$password);
                    //redireccionamos al controlador CRUD
                    redirect('crud');               
                }
            }
            //devolvemos los datos del usuario
            $data['dato'] = $respuesta;
            //cargamos la vista
            $this->load->view('editar_view',$data);
        }
    }
     
    public function eliminar($id=0)
    {
        //verificamos si existe el id
        $respuesta = $this->usuarios_model->get_usuario($id);
        //si nos retorna FALSE mostramos la pag 404.
        if($respuesta==false)
        show_404();
        else
        {
            //si existe eliminamos el usuario
            $this->usuarios_model->eliminar_usuario($id);
            //redireccionamos al controlador CRUD
            redirect('crud'); 
        }
    }
}